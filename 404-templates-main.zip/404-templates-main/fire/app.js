(async () => {
  await loadFirePreset(tsParticles);

  await tsParticles.load("tsparticles", {
    preset: "fire",
  });
})();
