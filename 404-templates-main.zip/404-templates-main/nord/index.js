(async () => {
  await tsParticles.load("tsparticles", {
    preset: "fountain",
  });
})();
